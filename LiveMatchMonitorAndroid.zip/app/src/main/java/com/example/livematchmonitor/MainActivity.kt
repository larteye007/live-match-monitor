package com.example.livematchmonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.Duration

data class MatchObservation(
    val id: String,
    val sport: String,
    val event: String,
    val liveStatus: String,
    val bookmakerStatus: String,
    val segment: String,
    val marketStatus: String,
    val firstMismatchAt: Instant?,
    val liveObservedAt: Instant,
    val bookmakerObservedAt: Instant,
    val identityConfidence: Double = 1.0
)

data class Detection(
    val statusMismatch: Boolean,
    val stalePrematchMarket: Boolean,
    val durationSeconds: Long,
    val reason: String
)

object Detector {
    private const val MIN_DELAY_SECONDS = 30L
    private const val MAX_AGE_SECONDS = 15L

    fun evaluate(m: MatchObservation, now: Instant = Instant.now()): Detection {
        val liveAge = Duration.between(m.liveObservedAt, now).seconds
        val bookAge = Duration.between(m.bookmakerObservedAt, now).seconds
        if (liveAge < 0 || bookAge < 0 ||
            liveAge > MAX_AGE_SECONDS || bookAge > MAX_AGE_SECONDS) {
            return Detection(false, false, 0, "Suppressed: stale or future-dated data")
        }
        if (m.identityConfidence < 0.90) {
            return Detection(false, false, 0, "Suppressed: event match is ambiguous")
        }
        val confirmedAt = m.firstMismatchAt ?: return Detection(false, false, 0, "Waiting for discrepancy")
        val duration = Duration.between(confirmedAt, now).seconds.coerceAtLeast(0)
        if (duration < MIN_DELAY_SECONDS) {
            return Detection(false, false, duration, "Waiting for 30-second persistence")
        }
        val isLive = m.liveStatus.equals("LIVE", true) ||
                m.liveStatus.equals("IN_PROGRESS", true) ||
                m.liveStatus.equals("HALFTIME", true) ||
                m.liveStatus.equals("COMPLETED", true)
        val bookNotStarted = m.bookmakerStatus.equals("NOT_STARTED", true) ||
                m.bookmakerStatus.equals("PREMATCH", true)
        val statusFlag = isLive && bookNotStarted
        val marketFlag = isLive &&
                m.marketStatus.equals("PREMATCH", true) &&
                !m.marketStatus.equals("SUSPENDED", true)
        return Detection(statusFlag, marketFlag, duration,
            if (statusFlag || marketFlag) "Discrepancy needs verification"
            else "No qualifying discrepancy")
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MonitorApp() }
    }
}

@Composable
fun MonitorApp() {
    var filter by remember { mutableStateOf("All") }
    val demo = remember {
        val now = Instant.now()
        listOf(
            MatchObservation(
                id = "demo-football-001", sport = "Football",
                event = "Example FC vs Sample United",
                liveStatus = "HALFTIME", bookmakerStatus = "NOT_STARTED",
                segment = "First half completed", marketStatus = "UNKNOWN",
                firstMismatchAt = now.minusSeconds(42),
                liveObservedAt = now, bookmakerObservedAt = now,
                identityConfidence = 0.98
            ),
            MatchObservation(
                id = "demo-table-tennis-002", sport = "Table tennis",
                event = "Player C vs Player D",
                liveStatus = "IN_PROGRESS", bookmakerStatus = "NOT_STARTED",
                segment = "Set 2", marketStatus = "PREMATCH",
                firstMismatchAt = now.minusSeconds(35),
                liveObservedAt = now, bookmakerObservedAt = now,
                identityConfidence = 0.96
            ),
            MatchObservation(
                id = "demo-basketball-003", sport = "Basketball",
                event = "Example City vs Sample Town",
                liveStatus = "LIVE", bookmakerStatus = "LIVE",
                segment = "Quarter 2", marketStatus = "LIVE",
                firstMismatchAt = null,
                liveObservedAt = now, bookmakerObservedAt = now,
                identityConfidence = 0.99
            )
        )
    }
    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text("Live Match Monitor") }
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("1xBet discrepancy monitor", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Prototype UI • Demo data only • No bets are placed",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = filter == "All", onClick = { filter = "All" }, label = { Text("All") })
                        FilterChip(selected = filter == "Alerts", onClick = { filter = "Alerts" }, label = { Text("Alerts") })
                    }
                }
                val shown = demo.map { it to Detector.evaluate(it) }
                    .filter { filter == "All" || it.second.statusMismatch || it.second.stalePrematchMarket }
                items(shown, key = { it.first.id }) { (match, detection) ->
                    ElevatedCard {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(match.event, style = MaterialTheme.typography.titleMedium)
                            Text("${match.sport} • ${match.segment}", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AssistChip(onClick = {}, label = { Text(match.liveStatus) })
                                Spacer(Modifier.width(6.dp))
                                AssistChip(onClick = {}, label = { Text("1xBet: ${match.bookmakerStatus}") })
                            }
                            Text("Market: ${match.marketStatus}")
                            Text("Discrepancy duration: ${detection.durationSeconds}s")
                            val alert = detection.statusMismatch || detection.stalePrematchMarket
                            Text(
                                if (alert) "FLAG: ${detection.reason}" else detection.reason,
                                color = if (alert) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                "Illustrative example — not a live event",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
                item {
                    HorizontalDivider()
                    Text("Before live monitoring", style = MaterialTheme.typography.titleSmall)
                    Text("Connect an authorized live-sports data provider and a permitted 1xBet observation source. This prototype currently uses simulated records.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
