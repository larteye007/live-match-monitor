package com.example.livematchmonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.Duration

private val BOOKMAKERS = listOf(
    "All bookmakers", "1xBet", "MyBet", "SoccaBet", "SupaBet Ghana",
    "Betway Ghana", "betPawa", "SportyBet", "Premier Bet Ghana"
)
private val SPORTS = listOf("All sports", "Football", "Table tennis", "Basketball")

data class MatchObservation(
    val id: String,
    val sport: String,
    val event: String,
    val liveStatus: String,
    val bookmakerStatus: String,
    val segment: String,
    val marketStatus: String,
    val firstMismatchAt: Instant?,
    val liveObservedAt: Instant,
    val bookmakerObservedAt: Instant,
    val bookmaker: String = "1xBet",
    val identityConfidence: Double = 1.0
)

data class Detection(
    val statusMismatch: Boolean,
    val stalePrematchMarket: Boolean,
    val durationSeconds: Long,
    val reason: String
)

object Detector {
    private const val MIN_DELAY_SECONDS = 30L
    private const val MAX_AGE_SECONDS = 300L

    fun evaluate(m: MatchObservation, now: Instant = Instant.now()): Detection {
        val liveAge = Duration.between(m.liveObservedAt, now).seconds
        val bookAge = Duration.between(m.bookmakerObservedAt, now).seconds
        if (liveAge < 0 || bookAge < 0 || liveAge > MAX_AGE_SECONDS || bookAge > MAX_AGE_SECONDS) {
            return Detection(false, false, 0, "Suppressed: demo observation is stale; tap Refresh demo")
        }
        if (m.identityConfidence < 0.90) {
            return Detection(false, false, 0, "Suppressed: event match is ambiguous")
        }
        val confirmedAt = m.firstMismatchAt
            ?: return Detection(false, false, 0, "No discrepancy detected")
        val duration = Duration.between(confirmedAt, now).seconds.coerceAtLeast(0)
        if (duration < MIN_DELAY_SECONDS) {
            return Detection(false, false, duration, "Waiting for 30-second persistence")
        }
        val isLive = listOf("LIVE", "IN_PROGRESS", "HALFTIME", "COMPLETED")
            .any { m.liveStatus.equals(it, true) }
        val bookNotStarted = listOf("NOT_STARTED", "PREMATCH")
            .any { m.bookmakerStatus.equals(it, true) }
        val statusFlag = isLive && bookNotStarted
        val marketFlag = isLive && m.marketStatus.equals("PREMATCH", true)
        return Detection(statusFlag, marketFlag, duration,
            if (statusFlag || marketFlag) "Demo discrepancy: verify with the source"
            else "No qualifying discrepancy")
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MonitorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonitorApp() {
    var view by remember { mutableStateOf("All") }
    var selectedSport by remember { mutableStateOf("All sports") }
    var selectedBookmaker by remember { mutableStateOf("All bookmakers") }
    var refreshedAt by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val demo = remember(refreshedAt) {
        val now = Instant.now()
        listOf(
            MatchObservation(
                id = "demo-football-001", sport = "Football",
                event = "Example FC vs Sample United", liveStatus = "HALFTIME",
                bookmakerStatus = "NOT_STARTED", segment = "Half-time",
                marketStatus = "UNKNOWN", firstMismatchAt = now.minusSeconds(42),
                liveObservedAt = now, bookmakerObservedAt = now,
                bookmaker = "1xBet", identityConfidence = 0.98
            ),
            MatchObservation(
                id = "demo-table-tennis-002", sport = "Table tennis",
                event = "Player C vs Player D", liveStatus = "IN_PROGRESS",
                bookmakerStatus = "NOT_STARTED", segment = "Set 2",
                marketStatus = "PREMATCH", firstMismatchAt = now.minusSeconds(35),
                liveObservedAt = now, bookmakerObservedAt = now,
                bookmaker = "MyBet", identityConfidence = 0.96
            ),
            MatchObservation(
                id = "demo-basketball-003", sport = "Basketball",
                event = "Example City vs Sample Town", liveStatus = "LIVE",
                bookmakerStatus = "LIVE", segment = "Quarter 2",
                marketStatus = "LIVE", firstMismatchAt = null,
                liveObservedAt = now, bookmakerObservedAt = now,
                bookmaker = "SupaBet Ghana", identityConfidence = 0.99
            ),
            MatchObservation(
                id = "demo-football-004", sport = "Football",
                event = "Demo Athletic vs Test Rovers", liveStatus = "LIVE",
                bookmakerStatus = "NOT_STARTED", segment = "Minute 61",
                marketStatus = "PREMATCH", firstMismatchAt = now.minusSeconds(55),
                liveObservedAt = now, bookmakerObservedAt = now,
                bookmaker = "SoccaBet", identityConfidence = 0.97
            )
        )
    }

    val shown = demo.map { it to Detector.evaluate(it) }
        .filter { (match, detection) ->
            (view != "Alerts" || detection.statusMismatch || detection.stalePrematchMarket) &&
            (selectedSport == "All sports" || match.sport == selectedSport) &&
            (selectedBookmaker == "All bookmakers" || match.bookmaker == selectedBookmaker)
        }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Live Match Monitor") },
                    actions = {
                        TextButton(onClick = { refreshedAt = System.currentTimeMillis() }) {
                            Text("Refresh demo")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Match discrepancy monitor", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "DEMO MODE • Not connected to live bookmaker feeds • No bets are placed",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("View", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = view == "All", onClick = { view = "All" }, label = { Text("ALL") })
                        FilterChip(selected = view == "Alerts", onClick = { view = "Alerts" }, label = { Text("ALERTS") })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Sport", style = MaterialTheme.typography.labelLarge)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        SPORTS.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                row.forEach { sport ->
                                    FilterChip(
                                        selected = selectedSport == sport,
                                        onClick = { selectedSport = sport },
                                        label = { Text(sport) }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Bookmaker", style = MaterialTheme.typography.labelLarge)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        BOOKMAKERS.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                row.forEach { bookmaker ->
                                    FilterChip(
                                        selected = selectedBookmaker == bookmaker,
                                        onClick = { selectedBookmaker = bookmaker },
                                        label = { Text(bookmaker) }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Showing ${shown.size} demo match(es)", style = MaterialTheme.typography.bodyMedium)
                }
                if (shown.isEmpty()) {
                    item {
                        ElevatedCard {
                            Text(
                                "No demo matches match these filters. Choose another sport/bookmaker or tap Refresh demo.",
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
                items(shown, key = { it.first.id }) { (match, detection) ->
                    ElevatedCard {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(match.event, style = MaterialTheme.typography.titleMedium)
                            Text("${match.sport} • ${match.segment}", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AssistChip(onClick = { selectedSport = match.sport }, label = { Text(match.liveStatus) })
                                Spacer(Modifier.width(6.dp))
                                AssistChip(onClick = { selectedBookmaker = match.bookmaker }, label = { Text("${match.bookmaker}: ${match.bookmakerStatus}") })
                            }
                            Text("Market: ${match.marketStatus}")
                            Text("Discrepancy duration: ${detection.durationSeconds}s")
                            val alert = detection.statusMismatch || detection.stalePrematchMarket
                            Text(
                                if (alert) "FLAG: ${detection.reason}" else detection.reason,
                                color = if (alert) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                "Illustrative example — not a live event",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
                item {
                    HorizontalDivider()
                    Text("Live data not connected", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "The bookmaker names are available as filters, but the app currently uses simulated records only. Real live alerts require an authorized sports-data API and permitted bookmaker data access. Kickoff/finish-time discrepancies cannot be verified from demo data.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
