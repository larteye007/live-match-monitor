# Live Match Monitor — Android starter project

This is an Android Studio project for a cross-sport event-state discrepancy monitor.

## Current features
- Native Android UI
- Example alert cards for football, table tennis and basketball
- 30-second discrepancy persistence rule
- Feed freshness and event-identity confidence checks
- Separate status-mismatch and pre-match-market flags
- No automated betting

## Important limitations
- The app uses simulated demo observations only.
- It does not connect to 1xBet or any live sports provider yet.
- A live implementation needs an authorized sports-data API and a permitted way to observe bookmaker event/market status.
- Never treat displayed odds or a stale event label as proof that a market is open or a bet will be accepted.

## Build an APK in Android Studio
1. Install Android Studio on a computer.
2. Open this project folder.
3. Allow Android Studio to install the Android SDK and sync Gradle.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK/Gradle installed, so this ZIP is source code and not a compiled APK.
